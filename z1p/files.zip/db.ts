import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

/**
 * Z1P.PRO database client.
 *
 * Uses the Supabase transaction pooler, which is required for serverless
 * runtimes. That pooler does not support prepared statements, so
 * `prepare` must be false. Keep `max: 1` so each serverless invocation
 * holds a single connection.
 *
 * Server-side only. Never import this into a Client Component.
 */

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error("DATABASE_URL is not set. Copy .env.example to .env.");
}

const client = postgres(connectionString, {
  prepare: false,
  max: 1,
  idle_timeout: 20,
  connect_timeout: 10,
});

// After running `npx drizzle-kit pull`, import the generated schema and
// pass it here for full type inference:
//   import * as schema from "./schema";
//   export const db = drizzle(client, { schema });
export const db = drizzle(client);

export { client as sql };
