import { defineConfig } from "drizzle-kit";

/**
 * Migrations and introspection run over the DIRECT connection, not the
 * pooler. The pooler runs in transaction mode and cannot hold the session
 * state that DDL requires.
 */
export default defineConfig({
  dialect: "postgresql",
  schema: "./lib/schema.ts",
  out: "./migrations",
  dbCredentials: {
    url: process.env.DIRECT_URL!,
  },
  verbose: true,
  strict: true,
});
