-- =====================================================================
-- Z1P.PRO
-- Migration 002: enable Row Level Security
-- =====================================================================
-- WHY THIS IS NOT OPTIONAL ON SUPABASE
--
-- Supabase automatically exposes every table in the `public` schema
-- through its REST API. Any table with RLS disabled is readable and
-- writable by anyone holding the anon key, which ships to the browser.
--
-- Z1P.PRO uses its own Google sign-in and talks to Postgres server-side
-- over DATABASE_URL, so `auth.uid()` policies do not apply here. The
-- correct posture is therefore: enable RLS everywhere and add no
-- permissive policies. The REST API then returns nothing, while your
-- server-side connection continues to work because the `postgres` role
-- bypasses RLS.
--
-- Verify that assumption before relying on it:
--   SELECT rolbypassrls FROM pg_roles WHERE rolname = current_user;
-- =====================================================================

BEGIN;

ALTER TABLE users             ENABLE ROW LEVEL SECURITY;
ALTER TABLE oauth_accounts    ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions          ENABLE ROW LEVEL SECURITY;
ALTER TABLE plans             ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions     ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments          ENABLE ROW LEVEL SECURITY;
ALTER TABLE concerns          ENABLE ROW LEVEL SECURITY;
ALTER TABLE concern_messages  ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts             ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags              ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_tags         ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_conversations  ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_messages       ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_usage_daily    ENABLE ROW LEVEL SECURITY;

-- Revoke the API roles explicitly. Belt and braces alongside RLS.
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon, authenticated;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon, authenticated;

-- Anything created later inherits the same posture.
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  REVOKE ALL ON TABLES FROM anon, authenticated;

COMMIT;

-- ---------------------------------------------------------------------
-- IF YOU LATER MIGRATE TO SUPABASE AUTH
-- ---------------------------------------------------------------------
-- Delete the REVOKE block above and add per-table policies instead.
-- Example shape, do not apply as-is:
--
--   CREATE POLICY "own conversations" ON ai_conversations
--     FOR ALL TO authenticated
--     USING (user_id = auth.uid())
--     WITH CHECK (user_id = auth.uid());
--
--   CREATE POLICY "published posts are public" ON posts
--     FOR SELECT TO anon, authenticated
--     USING (status = 'published');
-- ---------------------------------------------------------------------
