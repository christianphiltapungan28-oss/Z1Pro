-- =====================================================================
-- Z1P.PRO, powered by Flow Smart
-- Migration 001: initial schema
-- Target: PostgreSQL 15+
-- =====================================================================
-- Notes:
--   All timestamps are timestamptz. Store UTC, convert at the edge.
--   This matters for a Philippines-based audience (UTC+8).
--   Plan pricing is intentionally left NULL. Confirm real prices
--   before seeding them.
-- =====================================================================

BEGIN;

CREATE EXTENSION IF NOT EXISTS citext;      -- case-insensitive email
CREATE EXTENSION IF NOT EXISTS pg_trgm;     -- fuzzy search on titles

-- ---------------------------------------------------------------------
-- Shared helper: keep updated_at accurate without app-side logic
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------
CREATE TYPE user_role          AS ENUM ('member', 'moderator', 'admin');
CREATE TYPE subscription_status AS ENUM ('trialing', 'active', 'past_due', 'canceled', 'expired');
CREATE TYPE payment_status     AS ENUM ('pending', 'succeeded', 'failed', 'refunded');
CREATE TYPE post_status        AS ENUM ('draft', 'pending_review', 'published', 'rejected', 'archived');
CREATE TYPE concern_status     AS ENUM ('open', 'in_progress', 'resolved', 'closed');
CREATE TYPE concern_priority   AS ENUM ('low', 'normal', 'high', 'urgent');
CREATE TYPE message_role       AS ENUM ('system', 'user', 'assistant');

-- =====================================================================
-- 1. IDENTITY
-- =====================================================================

CREATE TABLE users (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email             CITEXT NOT NULL UNIQUE,
  email_verified_at TIMESTAMPTZ,
  display_name      TEXT,
  avatar_url        TEXT,
  locale            TEXT NOT NULL DEFAULT 'en',
  role              user_role NOT NULL DEFAULT 'member',
  -- Null when the account is Google-only. Never store plaintext.
  password_hash     TEXT,
  last_login_at     TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at        TIMESTAMPTZ
);

CREATE INDEX idx_users_active ON users (created_at) WHERE deleted_at IS NULL;

CREATE TRIGGER trg_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Google sign-in and any future provider. One row per linked provider.
CREATE TABLE oauth_accounts (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider         TEXT NOT NULL,          -- 'google', 'apple', ...
  provider_user_id TEXT NOT NULL,          -- the 'sub' claim from Google
  email_at_provider CITEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (provider, provider_user_id)
);

CREATE INDEX idx_oauth_accounts_user ON oauth_accounts (user_id);

-- Only needed if you manage sessions yourself rather than using
-- stateless JWTs or a hosted auth provider. Drop if unused.
CREATE TABLE sessions (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash   TEXT NOT NULL UNIQUE,       -- store a hash, never the token
  user_agent   TEXT,
  ip_address   INET,
  expires_at   TIMESTAMPTZ NOT NULL,
  revoked_at   TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_sessions_user ON sessions (user_id);
CREATE INDEX idx_sessions_expiry ON sessions (expires_at) WHERE revoked_at IS NULL;

-- =====================================================================
-- 2. PLANS, SUBSCRIPTIONS, PAYMENTS
-- =====================================================================

CREATE TABLE plans (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code               TEXT NOT NULL UNIQUE,   -- 'free', 'premium', 'pro'
  name               TEXT NOT NULL,
  description        TEXT,
  price_minor_units  INTEGER,                -- centavos. NULL until confirmed.
  currency           TEXT NOT NULL DEFAULT 'PHP',
  billing_interval   TEXT,                   -- 'month', 'year', NULL for free
  features           JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_active          BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order         SMALLINT NOT NULL DEFAULT 0,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TRIGGER trg_plans_updated_at
  BEFORE UPDATE ON plans
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE subscriptions (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id              UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id              UUID NOT NULL REFERENCES plans(id) ON DELETE RESTRICT,
  status               subscription_status NOT NULL DEFAULT 'active',
  -- Generic provider fields. Fill in once the payment processor is chosen.
  provider             TEXT,
  provider_customer_id TEXT,
  provider_subscription_id TEXT UNIQUE,
  current_period_start TIMESTAMPTZ,
  current_period_end   TIMESTAMPTZ,
  cancel_at_period_end BOOLEAN NOT NULL DEFAULT FALSE,
  canceled_at          TIMESTAMPTZ,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- A user may only hold one live subscription at a time.
CREATE UNIQUE INDEX idx_one_live_subscription
  ON subscriptions (user_id)
  WHERE status IN ('trialing', 'active', 'past_due');

CREATE INDEX idx_subscriptions_renewal ON subscriptions (current_period_end)
  WHERE status IN ('active', 'trialing');

CREATE TRIGGER trg_subscriptions_updated_at
  BEFORE UPDATE ON subscriptions
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE payments (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  subscription_id   UUID REFERENCES subscriptions(id) ON DELETE SET NULL,
  amount_minor_units INTEGER NOT NULL,
  currency          TEXT NOT NULL DEFAULT 'PHP',
  status            payment_status NOT NULL DEFAULT 'pending',
  provider          TEXT,
  provider_payment_id TEXT UNIQUE,
  failure_reason    TEXT,
  paid_at           TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (amount_minor_units >= 0)
);

CREATE INDEX idx_payments_user ON payments (user_id, created_at DESC);

CREATE TRIGGER trg_payments_updated_at
  BEFORE UPDATE ON payments
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- =====================================================================
-- 3. USER CONCERNS
-- =====================================================================

CREATE TABLE concerns (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID REFERENCES users(id) ON DELETE SET NULL,
  reference     TEXT NOT NULL UNIQUE,       -- human-facing ticket code
  subject       TEXT NOT NULL,
  body          TEXT NOT NULL,
  category      TEXT,                       -- 'bug', 'billing', 'account', ...
  status        concern_status NOT NULL DEFAULT 'open',
  priority      concern_priority NOT NULL DEFAULT 'normal',
  assigned_to   UUID REFERENCES users(id) ON DELETE SET NULL,
  first_response_at TIMESTAMPTZ,
  resolved_at   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_concerns_queue ON concerns (status, priority, created_at);
CREATE INDEX idx_concerns_user ON concerns (user_id, created_at DESC);

CREATE TRIGGER trg_concerns_updated_at
  BEFORE UPDATE ON concerns
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE concern_messages (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  concern_id  UUID NOT NULL REFERENCES concerns(id) ON DELETE CASCADE,
  author_id   UUID REFERENCES users(id) ON DELETE SET NULL,
  body        TEXT NOT NULL,
  is_internal BOOLEAN NOT NULL DEFAULT FALSE,  -- team-only note
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_concern_messages_thread ON concern_messages (concern_id, created_at);

-- =====================================================================
-- 4. BLOG AND USER STORIES
-- =====================================================================

CREATE TABLE posts (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id      UUID REFERENCES users(id) ON DELETE SET NULL,
  slug           TEXT NOT NULL UNIQUE,
  title          TEXT NOT NULL,
  excerpt        TEXT,
  body           TEXT NOT NULL,
  cover_image_url TEXT,                     -- file lives in object storage
  status         post_status NOT NULL DEFAULT 'draft',
  moderated_by   UUID REFERENCES users(id) ON DELETE SET NULL,
  moderation_note TEXT,
  published_at   TIMESTAMPTZ,
  view_count     INTEGER NOT NULL DEFAULT 0,
  -- Generated column powering site search
  search_vector  TSVECTOR GENERATED ALWAYS AS (
    setweight(to_tsvector('english', coalesce(title, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(excerpt, '')), 'B') ||
    setweight(to_tsvector('english', coalesce(body, '')), 'C')
  ) STORED,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_posts_search ON posts USING GIN (search_vector);
CREATE INDEX idx_posts_title_trgm ON posts USING GIN (title gin_trgm_ops);
CREATE INDEX idx_posts_published ON posts (published_at DESC) WHERE status = 'published';
CREATE INDEX idx_posts_moderation ON posts (created_at) WHERE status = 'pending_review';

CREATE TRIGGER trg_posts_updated_at
  BEFORE UPDATE ON posts
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE tags (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug       TEXT NOT NULL UNIQUE,
  name       TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE post_tags (
  post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  tag_id  UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (post_id, tag_id)
);

CREATE INDEX idx_post_tags_tag ON post_tags (tag_id);

-- =====================================================================
-- 5. AI ASSISTANT
-- =====================================================================

CREATE TABLE ai_conversations (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title          TEXT,
  last_message_at TIMESTAMPTZ,
  archived_at    TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ai_conversations_user
  ON ai_conversations (user_id, last_message_at DESC)
  WHERE archived_at IS NULL;

CREATE TRIGGER trg_ai_conversations_updated_at
  BEFORE UPDATE ON ai_conversations
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE ai_messages (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES ai_conversations(id) ON DELETE CASCADE,
  role            message_role NOT NULL,
  content         TEXT NOT NULL,
  model           TEXT,
  input_tokens    INTEGER,
  output_tokens   INTEGER,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ai_messages_thread ON ai_messages (conversation_id, created_at);

-- Per-user usage counter for enforcing Free vs Premium vs Pro limits.
CREATE TABLE ai_usage_daily (
  user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  usage_date    DATE NOT NULL,
  message_count INTEGER NOT NULL DEFAULT 0,
  input_tokens  BIGINT NOT NULL DEFAULT 0,
  output_tokens BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, usage_date)
);

-- =====================================================================
-- 6. SEED DATA
-- =====================================================================
-- Plan names and pricing are placeholders. Confirm before launch.

INSERT INTO plans (code, name, description, price_minor_units, billing_interval, sort_order)
VALUES
  ('free',    'Free',    'Core access with usage limits.', 0,    NULL,    1),
  ('premium', 'Premium', 'Expanded access.',               NULL, 'month', 2),
  ('pro',     'Pro',     'Full access.',                   NULL, 'month', 3);

-- Story categories taken from the stated blog purpose.
INSERT INTO tags (slug, name) VALUES
  ('life-change',        'Life Change'),
  ('skills',             'Skills'),
  ('routine',            'Routine and Habits'),
  ('motivation',         'Motivation and Discipline'),
  ('fitness-confidence', 'Fitness and Self-Confidence'),
  ('mental-health',      'Mental Health');

COMMIT;
